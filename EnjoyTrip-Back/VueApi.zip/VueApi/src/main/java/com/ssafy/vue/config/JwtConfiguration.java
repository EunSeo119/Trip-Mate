package com.ssafy.vue.config;

public class JwtConfiguration {

}
